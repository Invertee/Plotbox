from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"expected one match in {path}, found {count}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8", newline="\n")


def insert_before(path: Path, marker: str, addition: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(marker)
    if count != 1:
        raise RuntimeError(f"expected one insertion marker in {path}, found {count}")
    path.write_text(text.replace(marker, addition + marker, 1), encoding="utf-8", newline="\n")


def patch_models() -> None:
    path = ROOT / "packages/plotter_core/plotter_core/models.py"
    old = '''class SvgImportSettings(StrictModel):
    fill_mode: Literal["ignore", "outline", "hatch", "crosshatch"] = "outline"
    stroke_mode: Literal["centerline", "outline", "parallel"] = "centerline"
    hatch_spacing_mm: float = Field(default=2.0, gt=0)
    hatch_angle_degrees: float = 45.0
    fit_to_page: bool = True
'''
    new = '''class SvgImportSettings(StrictModel):
    fill_mode: Literal["ignore", "outline", "hatch", "crosshatch"] = "outline"
    stroke_mode: Literal["centerline", "outline", "parallel"] = "centerline"
    hatch_spacing_mm: float = Field(default=2.0, gt=0, le=100)
    hatch_angle_degrees: float = Field(default=45.0, ge=-360, le=360)
    fit_to_page: bool = True
    component_scope: Literal["groups", "elements"] = "groups"
    component_modes: dict[
        str,
        Literal["line", "hatch", "crosshatch", "ignore"],
    ] = Field(default_factory=dict, max_length=2000)

    @model_validator(mode="after")
    def component_mode_keys_are_bounded(self) -> SvgImportSettings:
        invalid = [
            component_id
            for component_id in self.component_modes
            if not component_id.strip() or len(component_id) > 256
        ]
        if invalid:
            raise ValueError("SVG component IDs must contain 1 to 256 characters")
        return self
'''
    replace_once(path, old, new)


def patch_projects() -> None:
    path = ROOT / "packages/plotter_core/plotter_core/projects.py"
    old = '''        mode_id = "import.svg" if detected_media_type == "image/svg+xml" else "import.raster"
        mode_version = "1.0.0"
'''
    new = '''        mode_id = "import.svg" if detected_media_type == "image/svg+xml" else "import.raster"
        mode_version = "1.1.0" if detected_media_type == "image/svg+xml" else "1.0.0"
'''
    replace_once(path, old, new)


def svg_import_function() -> str:
    return r'''def import_svg(
    content: bytes,
    recipe: ProjectRecipe,
    *,
    source_sha256: str | None = None,
    checkpoint: Callable[[str, int, int], None] | None = None,
) -> DesignDocument:
    """Convert SVG geometry into independently configurable plot components."""

    if len(content) > MAX_SVG_BYTES:
        raise ValueError("SVG exceeds the 25 MiB limit")
    lowered = content[:8192].lower()
    if b"<!doctype" in lowered or b"<!entity" in lowered:
        raise ValueError("SVG DTD and entity declarations are not supported")
    try:
        root = ET.fromstring(content)
    except ET.ParseError as error:
        raise ValueError(f"invalid SVG XML: {error}") from error
    if _local_name(root.tag) != "svg":
        raise ValueError("source asset root is not <svg>")
    elements = list(root.iter())
    if len(elements) > MAX_SVG_NODES:
        raise ValueError(f"SVG exceeds the {MAX_SVG_NODES} node limit")

    diagnostics: list[DesignDiagnostic] = []
    diagnostic_keys: set[tuple[str, str | None]] = set()

    def warn(code: str, message: str, element: ET.Element) -> None:
        element_id = element.attrib.get("id")
        key = (code, element_id)
        if key not in diagnostic_keys:
            diagnostics.append(DesignDiagnostic(code=code, message=message, element_id=element_id))
            diagnostic_keys.add(key)

    view_box_values = [float(value) for value in re.findall(NUMBER, root.get("viewBox", ""))]
    if len(view_box_values) == 4:
        min_x, min_y, view_width, view_height = view_box_values
    else:
        width_units = _number(root.get("width"), 300)
        height_units = _number(root.get("height"), 150)
        min_x, min_y, view_width, view_height = 0.0, 0.0, width_units, height_units
    if view_width <= 0 or view_height <= 0:
        raise ValueError("SVG viewBox must have positive dimensions")
    width_mm = _length_mm(root.get("width"), default=view_width * 25.4 / 96)
    height_mm = _length_mm(root.get("height"), default=view_height * 25.4 / 96)
    scale = (
        min(
            (recipe.page.width_mm - 2 * recipe.page.margin_mm) / width_mm,
            (recipe.page.height_mm - 2 * recipe.page.margin_mm) / height_mm,
        )
        if recipe.svg_import.fit_to_page
        else 1.0
    )
    output_width = width_mm * scale
    output_height = height_mm * scale
    left = (recipe.page.width_mm - output_width) / 2
    bottom = (recipe.page.height_mm - output_height) / 2
    sx = output_width / view_width
    sy = output_height / view_height
    root_matrix: Matrix = (
        sx,
        0,
        0,
        -sy,
        left - min_x * sx,
        bottom + output_height + min_y * sy,
    )

    id_map = {element.attrib["id"]: element for element in elements if "id" in element.attrib}
    element_paths: dict[int, str] = {id(root): "svg[1]"}

    def index_paths(parent: ET.Element) -> None:
        counts: dict[str, int] = {}
        parent_path = element_paths[id(parent)]
        for child in parent:
            tag = _local_name(child.tag)
            counts[tag] = counts.get(tag, 0) + 1
            element_paths[id(child)] = f"{parent_path}/{tag}[{counts[tag]}]"
            index_paths(child)

    index_paths(root)

    layers: dict[str, _LayerBuilder] = {}
    layer_order: list[str] = []
    layer_metadata: dict[str, dict[str, str | float | int | bool]] = {}
    layer_element_counts: dict[str, int] = {}
    component_layers: dict[str, str] = {}
    emitted_ids: set[tuple[str, str]] = set()
    element_counter = 0
    component_modes = recipe.svg_import.component_modes
    component_scope = recipe.svg_import.component_scope

    def component_id(kind: str, element: ET.Element) -> str:
        explicit_id = element.attrib.get("id")
        if explicit_id:
            return f"{kind}:{explicit_id}"
        return f"{kind}:path:{element_paths.get(id(element), _local_name(element.tag))}"

    def component_name(element: ET.Element, fallback: str) -> str:
        label = next(
            (value for key, value in element.attrib.items() if key.endswith("}label")),
            None,
        )
        return label or element.attrib.get("id") or fallback

    def builder(
        selected_component_id: str,
        name: str,
        kind: str,
        *,
        preferred_key: str,
        element: ET.Element | None = None,
    ) -> tuple[str, _LayerBuilder]:
        existing_key = component_layers.get(selected_component_id)
        if existing_key is not None:
            return existing_key, layers[existing_key]
        base_key = _slug(preferred_key)
        key = base_key
        suffix = 2
        while key in layers:
            key = f"{base_key}-{suffix}"
            suffix += 1
        layers[key] = _LayerBuilder(name=name, role=key)
        layer_order.append(key)
        component_layers[selected_component_id] = key
        metadata: dict[str, str | float | int | bool] = {
            "source": "svg",
            "svg_component_id": selected_component_id,
            "svg_component_kind": kind,
            "svg_component_name": name,
            "svg_drawing_mode": component_modes.get(selected_component_id, "defaults"),
        }
        if element is not None:
            metadata["svg_element_tag"] = _local_name(element.tag)
            if element.attrib.get("id"):
                metadata["svg_element_id"] = element.attrib["id"]
        layer_metadata[key] = metadata
        layer_element_counts[key] = 0
        return key, layers[key]

    default_component_id = "group:svg"
    default_key, default_layer = builder(
        default_component_id,
        "SVG",
        "group",
        preferred_key="svg",
        element=root,
    )

    def visit(
        element: ET.Element,
        parent_matrix: Matrix,
        inherited_style: dict[str, str],
        current_layer_key: str,
        current_layer: _LayerBuilder,
        current_group_id: str,
        current_group_name: str,
        *,
        use_stack: tuple[str, ...] = (),
        depth: int = 0,
    ) -> None:
        nonlocal element_counter
        element_counter += 1
        if checkpoint is not None:
            checkpoint("parse-svg", element_counter, len(elements))
        tag = _local_name(element.tag)
        if tag in UNSUPPORTED_TAGS:
            warn(UNSUPPORTED_TAGS[tag], f"SVG <{tag}> is not imported.", element)
            return
        if tag in {"defs", "symbol", "clipPath"} and not use_stack:
            if tag == "clipPath":
                warn(
                    "unsupported-clip-path",
                    "SVG clipPath is currently approximated by page clipping.",
                    element,
                )
            return
        style = _style(element, inherited_style)
        if style.get("display") == "none" or style.get("visibility") == "hidden":
            return
        local = _transform_matrix(element.get("transform"))
        combined = _multiply(parent_matrix, local)

        if tag == "g" and depth == 1:
            current_group_id = component_id("group", element)
            current_group_name = _layer_name(element)
            if component_scope == "groups":
                current_layer_key, current_layer = builder(
                    current_group_id,
                    current_group_name,
                    "group",
                    preferred_key=current_group_name,
                    element=element,
                )
        if tag == "use":
            href = element.get("href") or element.get("{http://www.w3.org/1999/xlink}href")
            if not href or not href.startswith("#"):
                warn(
                    "external-resource-removed",
                    "Only local fragment <use> references are supported.",
                    element,
                )
                return
            reference_id = href[1:]
            if reference_id in use_stack:
                warn("cyclic-use", "Cyclic SVG <use> reference was skipped.", element)
                return
            referenced = id_map.get(reference_id)
            if referenced is None:
                warn(
                    "missing-use-target",
                    f"SVG <use> target #{reference_id} was not found.",
                    element,
                )
                return
            translation = (1, 0, 0, 1, _number(element.get("x")), _number(element.get("y")))
            visit(
                referenced,
                _multiply(combined, translation),
                style,
                current_layer_key,
                current_layer,
                current_group_id,
                current_group_name,
                use_stack=(*use_stack, reference_id),
                depth=depth + 1,
            )
            return
        if tag in DRAWABLE_TAGS:
            element_id = element.attrib.get("id") or f"{tag}-{element_counter}"
            element_component_id = component_id("element", element)
            element_component_name = component_name(element, f"{tag} {element_counter}")
            selected_component_id = current_group_id
            selected_component_name = current_group_name
            selected_component_kind = "group"
            selected_layer_key = current_layer_key
            selected_layer = current_layer
            if component_scope == "elements":
                selected_component_id = element_component_id
                selected_component_name = element_component_name
                selected_component_kind = "element"
                selected_layer_key, selected_layer = builder(
                    selected_component_id,
                    selected_component_name,
                    "element",
                    preferred_key=element_component_name,
                    element=element,
                )

            drawing_mode = component_modes.get(selected_component_id)
            if drawing_mode != "ignore":
                raw_paths = _shape_paths(element, _slug(element_id), style)
                fill = style.get("fill", "black")
                stroke = style.get("stroke", "none")
                fill_mode = recipe.svg_import.fill_mode
                stroke_mode = recipe.svg_import.stroke_mode
                if drawing_mode == "line":
                    fill_mode = "outline"
                    stroke_mode = "centerline"
                elif drawing_mode in {"hatch", "crosshatch"}:
                    fill_mode = drawing_mode
                    stroke_mode = "centerline"
                layer_element_counts[selected_layer_key] += 1
                for raw_path in raw_paths:
                    transformed = _transform_path(raw_path, _multiply(root_matrix, combined))
                    candidates: list[DesignPath] = []
                    if stroke != "none":
                        if stroke_mode == "centerline":
                            candidates.append(transformed)
                        else:
                            width = max(
                                0.1,
                                _number(style.get("stroke-width"), 1.0) * (sx + sy) / 2,
                            )
                            offsets = (
                                (-width / 2, width / 2)
                                if stroke_mode == "outline"
                                else (-width, 0.0, width)
                            )
                            candidates.extend(
                                _offset_paths(
                                    transformed,
                                    offsets,
                                    stroke_mode,
                                )
                            )
                    if fill != "none":
                        if fill_mode == "outline":
                            candidates.append(transformed)
                        elif fill_mode in {"hatch", "crosshatch"} and transformed.closed:
                            candidates.extend(
                                _hatch_paths(
                                    transformed,
                                    spacing=recipe.svg_import.hatch_spacing_mm,
                                    angle_degrees=recipe.svg_import.hatch_angle_degrees,
                                    prefix="hatch",
                                )
                            )
                            if fill_mode == "crosshatch":
                                candidates.extend(
                                    _hatch_paths(
                                        transformed,
                                        spacing=recipe.svg_import.hatch_spacing_mm,
                                        angle_degrees=recipe.svg_import.hatch_angle_degrees + 90,
                                        prefix="crosshatch",
                                    )
                                )
                        elif fill_mode in {"hatch", "crosshatch"}:
                            warn(
                                "open-fill-ignored",
                                "A fill on an open path could not be hatched.",
                                element,
                            )
                    dash_value = style.get("stroke-dasharray")
                    if stroke != "none" and dash_value and dash_value != "none":
                        dash_values = [
                            _number(value) * (sx + sy) / 2
                            for value in re.findall(NUMBER, dash_value)
                        ]
                        candidates = [
                            dashed
                            for candidate in candidates
                            for dashed in _dash_paths(candidate, dash_values)
                        ]
                    for candidate in candidates:
                        metadata = dict(candidate.metadata)
                        metadata.update(
                            {
                                "svg_component_id": selected_component_id,
                                "svg_component_kind": selected_component_kind,
                                "svg_drawing_mode": drawing_mode or "defaults",
                                "svg_element_tag": tag,
                            }
                        )
                        if element.attrib.get("id"):
                            metadata["svg_element_id"] = element.attrib["id"]
                        candidate = candidate.model_copy(update={"metadata": metadata})
                        digest = canonical_sha256(candidate.model_dump(mode="json"))
                        emitted_key = (selected_component_id, digest)
                        if emitted_key in emitted_ids:
                            continue
                        emitted_ids.add(emitted_key)
                        assert selected_layer.paths is not None
                        selected_layer.paths.append(candidate)
                    selected_layer.preview_color = _color(stroke if stroke != "none" else fill)
        elif tag not in {"svg", "g", "defs", "symbol", "title", "desc", "metadata"}:
            warn("unsupported-element", f"SVG <{tag}> is not supported.", element)
        for child in element:
            visit(
                child,
                combined,
                style,
                current_layer_key,
                current_layer,
                current_group_id,
                current_group_name,
                use_stack=use_stack,
                depth=depth + 1,
            )

    visit(
        root,
        IDENTITY,
        {"fill": "black", "stroke": "none", "visibility": "visible"},
        default_key,
        default_layer,
        default_component_id,
        "SVG",
    )
    design_layers = [
        DesignLayer(
            layer_id=f"layer-{key}",
            name=layers[key].name,
            semantic_role=layers[key].role,
            preview_color=layers[key].preview_color,
            paths=layers[key].paths or [],
            metadata={
                **layer_metadata[key],
                "svg_element_count": layer_element_counts[key],
            },
        )
        for key in layer_order
        if layers[key].paths
    ]
    if not design_layers:
        raise ValueError("SVG import produced no plottable geometry")
    source_digest = source_sha256 or hashlib.sha256(content).hexdigest()
    document = DesignDocument(
        document_id=f"{recipe.project_id}-svg-design",
        page=recipe.page,
        layers=design_layers,
        metadata=DesignMetadata(
            generator_id=SVG_IMPORTER_ID,
            generator_version=SVG_IMPORTER_VERSION,
            seed="",
            quality=recipe.mode.quality,
            source_asset_sha256=source_digest,
            diagnostics=diagnostics,
        ),
    )
    digest = canonical_sha256(document)
    if checkpoint is not None:
        checkpoint("complete", len(elements), len(elements))
    return document.model_copy(
        update={"metadata": document.metadata.model_copy(update={"normalized_sha256": digest})}
    )
'''


def patch_svg_importer() -> None:
    path = ROOT / "packages/plotter_core/plotter_core/importers/svg.py"
    replace_once(path, 'SVG_IMPORTER_VERSION = "1.0.0"', 'SVG_IMPORTER_VERSION = "1.1.0"')
    text = path.read_text(encoding="utf-8")
    marker = "def import_svg(\n"
    index = text.find(marker)
    if index < 0:
        raise RuntimeError("could not find import_svg function")
    path.write_text(text[:index] + svg_import_function(), encoding="utf-8", newline="\n")


def patch_api() -> None:
    path = ROOT / "services/api/plotterapp_api/main.py"
    replace_once(
        path,
        '''    RasterVectorizeSettings,\n    SvgExportBundle,\n''',
        '''    RasterVectorizeSettings,\n    SvgExportBundle,\n    SvgImportSettings,\n''',
    )
    replace_once(path, '        return "import.svg", "1.0.0", run_import', '        return "import.svg", "1.1.0", run_import')
    replace_once(path, '        version="0.3.0",', '        version="0.4.0",')
    old = '''            ModeManifest(
                kind="importer",
                id="import.svg",
                version="1.0.0",
                name="SVG import",
                category="convert",
                quality_levels=quality_levels,
            ),
'''
    new = '''            ModeManifest(
                kind="importer",
                id="import.svg",
                version="1.1.0",
                name="SVG to G-code",
                description=(
                    "Break an SVG into group or element components, assign line, hatch, "
                    "crosshatch, or ignore treatments, then plan validated G-code passes."
                ),
                category="convert",
                quality_levels=quality_levels,
                algorithms=["line", "hatch", "crosshatch", "ignore"],
                parameter_schema=SvgImportSettings.model_json_schema(),
            ),
'''
    replace_once(path, old, new)


def patch_types() -> None:
    path = ROOT / "apps/web/src/types.ts"
    old_layer = '''export interface DesignLayer {
  layer_id: string;
  name: string;
  semantic_role: string;
  preview_color: string;
  visible: boolean;
  paths: DesignPath[];
}
'''
    new_layer = '''export interface DesignLayer {
  layer_id: string;
  name: string;
  semantic_role: string;
  preview_color: string;
  visible: boolean;
  paths: DesignPath[];
  metadata?: Record<string, string | number | boolean>;
}
'''
    replace_once(path, old_layer, new_layer)
    old_svg = '''  svg_import: {
    fill_mode: "ignore" | "outline" | "hatch" | "crosshatch";
    stroke_mode: "centerline" | "outline" | "parallel";
    hatch_spacing_mm: number;
    hatch_angle_degrees: number;
    fit_to_page: boolean;
  };
'''
    new_svg = '''  svg_import: {
    fill_mode: "ignore" | "outline" | "hatch" | "crosshatch";
    stroke_mode: "centerline" | "outline" | "parallel";
    hatch_spacing_mm: number;
    hatch_angle_degrees: number;
    fit_to_page: boolean;
    component_scope?: "groups" | "elements";
    component_modes?: Record<string, "line" | "hatch" | "crosshatch" | "ignore">;
  };
'''
    replace_once(path, old_svg, new_svg)


def svg_controls_component() -> str:
    return r'''import { useMemo } from "react";

import { NumericInput } from "./NumericInput";
import type { DesignDocument, ProjectRecipe } from "./types";

type SvgDrawingMode = "line" | "hatch" | "crosshatch" | "ignore";

interface SvgConversionControlsProps {
  project: ProjectRecipe;
  design: DesignDocument | null;
  onChange: (project: ProjectRecipe) => void;
}

interface SvgComponentRow {
  id: string;
  name: string;
  kind: "group" | "element";
  elementCount: number | null;
}

const EMPTY_COMPONENT_MODES: Record<string, SvgDrawingMode> = {};

function stringMetadata(
  metadata: Record<string, string | number | boolean> | undefined,
  key: string,
): string | null {
  const value = metadata?.[key];
  return typeof value === "string" ? value : null;
}

function numberMetadata(
  metadata: Record<string, string | number | boolean> | undefined,
  key: string,
): number | null {
  const value = metadata?.[key];
  return typeof value === "number" ? value : null;
}

export function SvgConversionControls({
  project,
  design,
  onChange,
}: SvgConversionControlsProps) {
  const settings = project.svg_import;
  const componentScope = settings.component_scope ?? "groups";
  const componentModes = settings.component_modes ?? EMPTY_COMPONENT_MODES;
  const expectedKind = componentScope === "elements" ? "element" : "group";
  const sourceName =
    project.assets.find((item) => item.asset_id === project.source_asset_id)?.original_filename ??
    "No SVG selected";

  const components = useMemo(() => {
    const rows = new Map<string, SvgComponentRow>();
    if (design?.metadata.generator_id === "import.svg") {
      for (const layer of design.layers) {
        const id = stringMetadata(layer.metadata, "svg_component_id");
        const kind = stringMetadata(layer.metadata, "svg_component_kind");
        if (!id || kind !== expectedKind) continue;
        rows.set(id, {
          id,
          name: stringMetadata(layer.metadata, "svg_component_name") ?? layer.name,
          kind,
          elementCount: numberMetadata(layer.metadata, "svg_element_count"),
        });
      }
    }
    for (const id of Object.keys(componentModes).sort()) {
      if (!id.startsWith(`${expectedKind}:`) || rows.has(id)) continue;
      rows.set(id, {
        id,
        name: id.replace(/^\w+:/, ""),
        kind: expectedKind,
        elementCount: null,
      });
    }
    return [...rows.values()];
  }, [componentModes, design, expectedKind]);

  const update = (changes: Partial<ProjectRecipe["svg_import"]>) =>
    onChange({
      ...project,
      svg_import: { ...settings, ...changes },
    });

  const updateComponentMode = (componentId: string, mode: "defaults" | SvgDrawingMode) => {
    const next = { ...componentModes };
    if (mode === "defaults") delete next[componentId];
    else next[componentId] = mode;
    update({ component_modes: next });
  };

  return (
    <fieldset>
      <legend>SVG to G-code · v1.1</legend>
      <p className="source-name">{sourceName}</p>
      <label>
        Component breakdown
        <select
          aria-label="SVG component breakdown"
          value={componentScope}
          onChange={(event) =>
            update({
              component_scope: event.target.value as "groups" | "elements",
            })
          }
        >
          <option value="groups">SVG layers and top-level groups</option>
          <option value="elements">Individual SVG elements</option>
        </select>
      </label>
      <label className="checkbox-label">
        <input
          aria-label="Fit SVG to page"
          type="checkbox"
          checked={settings.fit_to_page}
          onChange={(event) => update({ fit_to_page: event.target.checked })}
        />
        Fit to safe page area
      </label>
      <div className="field-row">
        <label>
          Default fill treatment
          <select
            aria-label="Fill treatment"
            value={settings.fill_mode}
            onChange={(event) =>
              update({
                fill_mode: event.target.value as ProjectRecipe["svg_import"]["fill_mode"],
              })
            }
          >
            <option value="ignore">Ignore</option>
            <option value="outline">Outline</option>
            <option value="hatch">Hatch</option>
            <option value="crosshatch">Crosshatch</option>
          </select>
        </label>
        <label>
          Default stroke treatment
          <select
            aria-label="Stroke treatment"
            value={settings.stroke_mode}
            onChange={(event) =>
              update({
                stroke_mode: event.target.value as ProjectRecipe["svg_import"]["stroke_mode"],
              })
            }
          >
            <option value="centerline">Centerline</option>
            <option value="outline">Outline</option>
            <option value="parallel">Parallel approximation</option>
          </select>
        </label>
      </div>
      <div className="field-row">
        <label>
          Hatch spacing mm
          <NumericInput
            aria-label="Hatch spacing"
            type="number"
            min="0.1"
            max="100"
            step="0.1"
            value={settings.hatch_spacing_mm}
            onChange={(event) => update({ hatch_spacing_mm: Number(event.target.value) })}
          />
        </label>
        <label>
          Hatch angle
          <NumericInput
            aria-label="Hatch angle"
            type="number"
            min="-360"
            max="360"
            value={settings.hatch_angle_degrees}
            onChange={(event) => update({ hatch_angle_degrees: Number(event.target.value) })}
          />
        </label>
      </div>
      <p className="field-help">
        Convert once to inspect components. Each component becomes its own design layer and pen pass,
        so it can use a separate physical pen in the pass editor.
      </p>
      {components.length > 0 ? (
        <section className="svg-component-section" aria-label="SVG component drawing modes">
          <div className="svg-component-heading">
            <strong>Component drawing modes</strong>
            <span>{components.length}</span>
          </div>
          <div className="svg-component-list">
            {components.map((component) => (
              <article className="svg-component-card" key={component.id}>
                <div>
                  <strong>{component.name}</strong>
                  <code>{component.id}</code>
                  {component.elementCount !== null && (
                    <small>
                      {component.elementCount} source element
                      {component.elementCount === 1 ? "" : "s"}
                    </small>
                  )}
                </div>
                <label>
                  Drawing mode
                  <select
                    aria-label={`Drawing mode for ${component.name}`}
                    value={componentModes[component.id] ?? "defaults"}
                    onChange={(event) =>
                      updateComponentMode(
                        component.id,
                        event.target.value as "defaults" | SvgDrawingMode,
                      )
                    }
                  >
                    <option value="defaults">Use defaults</option>
                    <option value="line">Line drawing</option>
                    <option value="hatch">Hatch fill</option>
                    <option value="crosshatch">Crosshatch fill</option>
                    <option value="ignore">Ignore component</option>
                  </select>
                </label>
              </article>
            ))}
          </div>
          <p className="field-help">
            Reconvert after changing a component mode. Hatch settings above apply to all selected
            hatch and crosshatch components.
          </p>
        </section>
      ) : (
        <p className="field-help">
          Component controls appear here after the SVG has been converted once.
        </p>
      )}
    </fieldset>
  );
}
'''


def patch_frontend() -> None:
    controls_path = ROOT / "apps/web/src/SvgConversionControls.tsx"
    controls_path.write_text(svg_controls_component(), encoding="utf-8", newline="\n")

    app_path = ROOT / "apps/web/src/App.tsx"
    insert_before(
        app_path,
        'import { SingleLineControls } from "./SingleLineControls";\n',
        'import { SvgConversionControls } from "./SvgConversionControls";\n',
    )
    text = app_path.read_text(encoding="utf-8")
    start_marker = '''              {toolWorkspace === "image" &&
                (project.mode.mode_id === "import.svg" ? (
                  <fieldset>
                    <legend>SVG conversion</legend>
'''
    start = text.find(start_marker)
    if start < 0:
        raise RuntimeError("could not find SVG controls start")
    end_marker = '''                  </fieldset>
                ) : project.mode.mode_id === "import.raster" ? (
'''
    end = text.find(end_marker, start)
    if end < 0:
        raise RuntimeError("could not find SVG controls end")
    replacement = '''              {toolWorkspace === "image" &&
                (project.mode.mode_id === "import.svg" ? (
                  <SvgConversionControls
                    project={project}
                    design={design}
                    onChange={(updated) => {
                      setPlan(null);
                      setBundle(null);
                      setSendResult(null);
                      setSvgBundle(null);
                      setProject(updated);
                    }}
                  />
                ) : project.mode.mode_id === "import.raster" ? (
'''
    text = text[:start] + replacement + text[end + len(end_marker) :]
    if text.count('                        ? "Convert SVG"') != 1:
        raise RuntimeError("could not find SVG conversion button label")
    text = text.replace(
        '                        ? "Convert SVG"',
        '                        ? "Convert SVG and plan"',
        1,
    )
    app_path.write_text(text, encoding="utf-8", newline="\n")

    styles_path = ROOT / "apps/web/src/styles.css"
    styles = styles_path.read_text(encoding="utf-8")
    addition = r'''

.svg-component-section {
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px solid var(--line);
}

.svg-component-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 8px;
}

.svg-component-heading span {
  min-width: 24px;
  padding: 2px 7px;
  border-radius: 999px;
  color: var(--paper);
  background: var(--moss);
  text-align: center;
  font-size: 11px;
}

.svg-component-list {
  display: grid;
  gap: 8px;
}

.svg-component-card {
  display: grid;
  gap: 8px;
  padding: 10px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: rgba(255, 253, 247, 0.72);
}

.svg-component-card > div {
  display: grid;
  gap: 3px;
  min-width: 0;
}

.svg-component-card code {
  overflow: hidden;
  color: var(--muted);
  font-size: 10px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.svg-component-card small {
  color: var(--muted);
}
'''
    if ".svg-component-section" in styles:
        raise RuntimeError("SVG component styles already exist")
    styles_path.write_text(styles.rstrip() + addition + "\n", encoding="utf-8", newline="\n")


def patch_tests() -> None:
    path = ROOT / "packages/plotter_core/tests/test_svg_import.py"
    replace_once(
        path,
        'from plotter_core.importers import import_svg\nfrom plotter_core.models import ProjectRecipe\n',
        'from plotter_core.gcode import export_gcode_bundle\nfrom plotter_core.importers import import_svg\nfrom plotter_core.models import MachineProfile, ProjectRecipe\n',
    )
    addition = r'''


def test_svg_element_modes_create_independent_layers_and_valid_gcode() -> None:
    recipe = ProjectRecipe(project_id="svg-components", name="SVG component conversion")
    recipe.svg_import.fit_to_page = False
    recipe.svg_import.component_scope = "elements"
    recipe.svg_import.component_modes = {
        "element:panel": "crosshatch",
        "element:linework": "line",
        "element:ignored": "ignore",
    }
    content = b"""<svg xmlns="http://www.w3.org/2000/svg" width="60mm" height="30mm"
        viewBox="0 0 60 30">
      <g id="artwork">
        <rect id="panel" x="2" y="2" width="20" height="20" fill="#cccccc" />
        <path id="linework" d="M 30 5 L 55 20" fill="none" stroke="#111111" />
        <circle id="ignored" cx="45" cy="10" r="5" fill="#333333" />
      </g>
    </svg>"""

    design = import_svg(content, recipe)

    component_ids = [layer.metadata["svg_component_id"] for layer in design.layers]
    assert component_ids == ["element:panel", "element:linework"]
    panel, linework = design.layers
    assert panel.metadata["svg_drawing_mode"] == "crosshatch"
    assert any("-hatch-" in path.path_id for path in panel.paths)
    assert any("-crosshatch-" in path.path_id for path in panel.paths)
    assert linework.metadata["svg_drawing_mode"] == "line"
    assert len(linework.paths) == 1
    assert not linework.paths[0].closed
    assert all(
        path.metadata["svg_component_id"] == layer.metadata["svg_component_id"]
        for layer in design.layers
        for path in layer.paths
    )

    recipe.passes = [
        recipe.passes[index].model_copy(
            update={
                "pass_id": f"pass-svg-{index + 1}",
                "name": layer.name,
                "semantic_role": layer.semantic_role,
                "preview_color": layer.preview_color,
                "source_layer_ids": [layer.layer_id],
            }
        )
        for index, layer in enumerate(design.layers)
    ]
    plan = build_plot_plan(recipe, design)
    bundle = export_gcode_bundle(recipe, plan, MachineProfile())

    assert plan.statistics.pass_count == 2
    assert plan.statistics.path_count == sum(len(layer.paths) for layer in design.layers)
    assert bundle.manifest.valid
    assert any(program.filename == "combined.nc" for program in bundle.programs)
    assert all(program.validation.valid for program in bundle.programs)
'''
    text = path.read_text(encoding="utf-8")
    if "test_svg_element_modes_create_independent_layers_and_valid_gcode" in text:
        raise RuntimeError("SVG component test already exists")
    path.write_text(text.rstrip() + addition + "\n", encoding="utf-8", newline="\n")

    api_test = ROOT / "services/api/tests/test_api.py"
    old_modes = '''    assert raster["parameter_schema"]["properties"]["algorithm"]["enum"] == raster["algorithms"]
    hybrid = next(item for item in modes if item["id"] == "builtin.map-glyphscape")
'''
    new_modes = '''    assert raster["parameter_schema"]["properties"]["algorithm"]["enum"] == raster["algorithms"]
    svg = next(item for item in modes if item["id"] == "import.svg")
    assert svg["version"] == "1.1.0"
    assert svg["name"] == "SVG to G-code"
    assert svg["algorithms"] == ["line", "hatch", "crosshatch", "ignore"]
    assert svg["parameter_schema"]["properties"]["component_scope"]["enum"] == [
        "groups",
        "elements",
    ]
    hybrid = next(item for item in modes if item["id"] == "builtin.map-glyphscape")
'''
    replace_once(api_test, old_modes, new_modes)
    old_export = '''        plan = client.post(f"/api/projects/{project_id}/plan")
        assert plan.status_code == 200, plan.text
        assert plan.json()["source_design_sha256"] == design_hash
        svg_bundle = client.post(f"/api/projects/{project_id}/export/svg").json()
'''
    new_export = '''        plan = client.post(f"/api/projects/{project_id}/plan")
        assert plan.status_code == 200, plan.text
        assert plan.json()["source_design_sha256"] == design_hash
        gcode_bundle = client.post(f"/api/projects/{project_id}/export/gcode", json={}).json()
        assert gcode_bundle["manifest"]["valid"] is True
        assert any(item["filename"] == "combined.nc" for item in gcode_bundle["programs"])
        svg_bundle = client.post(f"/api/projects/{project_id}/export/svg").json()
'''
    replace_once(api_test, old_export, new_export)

    component_test = ROOT / "apps/web/src/SvgConversionControls.test.tsx"
    component_test.write_text(
        r'''import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { SvgConversionControls } from "./SvgConversionControls";
import type { DesignDocument, ProjectRecipe } from "./types";

const project = {
  project_id: "svg-components-ui",
  assets: [
    {
      asset_id: "asset-svg",
      original_filename: "components.svg",
      media_type: "image/svg+xml",
      sha256: "a".repeat(64),
      byte_count: 100,
    },
  ],
  source_asset_id: "asset-svg",
  svg_import: {
    fill_mode: "outline",
    stroke_mode: "centerline",
    hatch_spacing_mm: 2,
    hatch_angle_degrees: 45,
    fit_to_page: true,
    component_scope: "elements",
    component_modes: {},
  },
} as unknown as ProjectRecipe;

const design = {
  metadata: { generator_id: "import.svg" },
  layers: [
    {
      layer_id: "layer-panel",
      name: "panel",
      semantic_role: "panel",
      preview_color: "#171717",
      visible: true,
      paths: [],
      metadata: {
        svg_component_id: "element:panel",
        svg_component_kind: "element",
        svg_component_name: "Panel",
        svg_element_count: 1,
      },
    },
  ],
} as unknown as DesignDocument;

describe("SVG conversion controls", () => {
  it("assigns a drawing mode to an imported SVG component", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<SvgConversionControls project={project} design={design} onChange={onChange} />);

    expect(screen.getByRole("group", { name: "SVG to G-code · v1.1" })).toBeVisible();
    expect(screen.getByText("components.svg")).toBeVisible();
    expect(screen.getByText("element:panel")).toBeVisible();

    await user.selectOptions(screen.getByLabelText("Drawing mode for Panel"), "crosshatch");

    expect(onChange).toHaveBeenCalledWith(
      expect.objectContaining({
        svg_import: expect.objectContaining({
          component_modes: { "element:panel": "crosshatch" },
        }),
      }),
    );
  });
});
''',
        encoding="utf-8",
        newline="\n",
    )


def patch_readme() -> None:
    path = ROOT / "README.md"
    old = '''3. For SVG, select fill treatment (`ignore`, `outline`, `hatch`, or `crosshatch`) and stroke
   treatment (`centerline`, `outline`, or `parallel`).
'''
    new = '''3. For SVG, choose whether components follow top-level groups/layers or individual elements,
   select default fill and stroke treatments, convert once to inspect the component list, then assign
   line, hatch, crosshatch, or ignore treatment to each component before planning G-code.
'''
    replace_once(path, old, new)
    marker = '''## SVG support and diagnostics

'''
    addition = '''## SVG support and diagnostics

SVG conversion can preserve top-level authoring layers or split every drawable SVG element into a
stable component. Each component becomes an independent Plotbox design layer and pen pass. Component
overrides can use line drawing, hatch fill, crosshatch fill, or ignore while the remaining components
continue to use the project defaults. The normal pass editor then assigns physical pens and exports
validated per-pass or combined G-code.

'''
    replace_once(path, marker, addition)


def main() -> None:
    patch_models()
    patch_projects()
    patch_svg_importer()
    patch_api()
    patch_types()
    patch_frontend()
    patch_tests()
    patch_readme()


if __name__ == "__main__":
    main()
